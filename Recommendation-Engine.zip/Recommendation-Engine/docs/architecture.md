# System Architecture

## Overview

The Recommendation Engine follows a classic 3-tier architecture:

```
┌───────────────────┐        HTTP/JSON (fetch)        ┌───────────────────────┐        JDBC        ┌──────────────┐
│   Frontend (SPA)   │ ───────────────────────────────▶│  Spring Boot Backend   │ ──────────────────▶│   MySQL 8+   │
│ HTML/CSS/JS + Chart│ ◀─────────────────────────────── │  (REST API, port 8080) │ ◀────────────────── │  Database    │
│  .js (port 5500)   │                                  │                        │                     │              │
└───────────────────┘                                  └───────────────────────┘                     └──────────────┘
```

## Backend Layers

```
controller/   -> Handles HTTP requests, request validation, response shaping
service/      -> Business logic, orchestrates repositories and algorithms
algorithm/    -> Pure DSA logic (Search, Sort, Similarity, Recommendation) - framework-free
repository/   -> Spring Data JPA interfaces talking to MySQL
model/        -> JPA entities (User, Item, Interaction, Preference) + Recommendation POJO
config/       -> CORS configuration, global exception handling
```

The `algorithm` package is deliberately kept independent of Spring
annotations. It operates purely on `ArrayList`, `HashMap`, `HashSet`, and
`PriorityQueue` so it can be understood, tested, and explained in the viva
without any framework context.

## Request Flow: Generating Recommendations

1. Frontend (`recommendations.html`) calls `Api.getRecommendations(userId, limit)`.
2. `RecommendationController` receives `GET /api/recommendations/{userId}?limit=N`.
3. Controller validates the user exists and delegates to `RecommendationService`.
4. `RecommendationService` loads all Users, Items, Interactions, and
   Preferences from MySQL (via JPA repositories) into `ArrayList`s.
5. `RecommendationAlgorithm.generateRecommendations()` runs the full DSA
   pipeline (HashMap lookups → HashSet filtering → scoring → PriorityQueue
   ranking → Merge Sort → Top-N).
6. Controller wraps the result in the JSON contract shared with the
   frontend and returns it.
7. `recommendations.js` renders the ranked cards, with local filtering
   and sorting handled client-side for a snappy demo experience.

## Data Flow Summary

```
CSV dataset --> MySQL (recommendation_engine.sql) --> JPA Repositories
                                                              │
                                                              ▼
                                                    RecommendationService
                                                              │
                                                              ▼
                                                    RecommendationAlgorithm
                                          (ArrayList, HashMap, HashSet, PriorityQueue)
                                                              │
                                                              ▼
                                                     REST JSON response
                                                              │
                                                              ▼
                                                   Frontend (fetch + render)
```

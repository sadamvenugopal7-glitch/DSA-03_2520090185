# DSA Complexity Analysis

## Data Structures

| Structure | Used For | Access | Insertion | Deletion | Search |
|---|---|---|---|---|---|
| ArrayList | Users, Items, Interactions, Results | O(1) by index | O(1) amortized (end), O(n) (middle) | O(n) | O(n) |
| HashMap | userId→User, itemId→Item, category→score | O(1) average | O(1) average | O(1) average | O(1) average |
| HashSet | Interacted item IDs, unique categories | - | O(1) average | O(1) average | O(1) average |
| PriorityQueue | Ranking recommendation candidates | O(1) peek | O(log n) | O(log n) | O(n) |

HashMap/HashSet's O(1) average case relies on a good hash function and low
load factor; worst case (many collisions) degrades to O(n), which is why
Java's HashMap resizes and rehashes automatically as it grows.

## Algorithms

| Algorithm | Best | Average | Worst | Space |
|---|---|---|---|---|
| Linear Search | O(1) | O(n) | O(n) | O(1) |
| Binary Search | O(1) | O(log n) | O(log n) | O(1) |
| Merge Sort | O(n log n) | O(n log n) | O(n log n) | O(n) |
| Similarity Calculation (per item) | O(p) | O(p) | O(p) | O(1) |
| Full Recommendation Generation | - | O(n·p + n log n) | O(n·p + n log n) | O(n) |

Where `n` = number of candidate items, `p` = number of the user's stated
preferences.

## Why Merge Sort over Collections.sort()?

`Collections.sort()` wraps a highly-optimized Timsort, but the project
requires demonstrating the actual divide-and-conquer sorting algorithm
that a DSA course teaches. Merge Sort's guaranteed O(n log n) behaviour
(no worst-case degradation, unlike Quick Sort's O(n²)) also makes it a
safe, predictable choice for scoring and ranking data that must be
returned quickly to the frontend.

## Why a PriorityQueue for ranking?

Rather than sorting every single item and then slicing the Top-N, a
PriorityQueue (binary heap) lets the algorithm efficiently maintain and
extract the current best candidate in O(log n) per operation, which pairs
naturally with the algorithm's "insert while scoring, extract from top"
flow (Steps 13-14 in the recommendation pipeline).

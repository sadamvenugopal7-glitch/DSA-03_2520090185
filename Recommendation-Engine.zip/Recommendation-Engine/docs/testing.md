# Test Cases

Manual API test cases for the Recommendation Engine. Run the backend
(`mvn spring-boot:run`) and use `curl`, Postman, or the frontend to
reproduce these.

---

### TC-01: Valid user — get recommendations

- **Input:** `GET /api/recommendations/1?limit=5`
- **Expected Output:** HTTP 200, JSON with `userId: 1` and up to 5
  recommendation objects sorted by `finalScore` descending.
- **Actual Output:** HTTP 200 — 5 recommendations returned, ranks 1–5,
  `finalScore` strictly non-increasing. ✅ Pass

---

### TC-02: Invalid user ID

- **Input:** `GET /api/recommendations/999999`
- **Expected Output:** HTTP 404 with a clean JSON error message (no
  stack trace).
- **Actual Output:** HTTP 404 —
  `{ "success": false, "status": 404, "message": "User with ID 999999 was not found." }` ✅ Pass

---

### TC-03: User with no interaction history (cold start)

- **Input:** A freshly inserted user with a `preferred_category` but no
  rows in `interactions` or `preferences`. `GET /api/recommendations/{id}`
- **Expected Output:** HTTP 200 — recommendations still returned, biased
  toward the user's `preferred_category` and item popularity.
- **Actual Output:** HTTP 200 — top results are mostly from the
  preferred category, with high popularity items filling remaining slots. ✅ Pass

---

### TC-04: User with rich interaction history

- **Input:** `GET /api/recommendations/2?limit=10` (user with 10+ interactions)
- **Expected Output:** Items the user has already interacted with never
  appear in the result set.
- **Actual Output:** Verified — none of the returned `itemId`s intersect
  with the user's `interactions` item IDs (HashSet exclusion confirmed). ✅ Pass

---

### TC-05: Duplicate interaction submission

- **Input:** `POST /api/interactions` twice with identical body
  `{ "userId": 1, "itemId": 105, "interactionType": "view" }`
- **Expected Output:** Both requests succeed (HTTP 201) and create two
  separate interaction rows — the system logs interactions as events, not
  a unique state, so duplicates are allowed but do not break ranking
  (interaction score is capped at 1.0 per item).
- **Actual Output:** Two rows created; recommendation interaction score
  for that item does not exceed 1.0 regardless of repeat count. ✅ Pass

---

### TC-06: Category filter

- **Input:** `GET /api/items/category/Electronics`
- **Expected Output:** HTTP 200 — only items where `category ==
  "Electronics"`.
- **Actual Output:** HTTP 200 — all returned items have
  `category: "Electronics"`. ✅ Pass

---

### TC-07: Rating filter (frontend)

- **Input:** On `recommendations.html`, set "Minimum Rating" to `4+` after
  generating recommendations for user 1.
- **Expected Output:** Only cards with `rating >= 4.0` remain visible.
- **Actual Output:** Card list re-renders instantly, all remaining cards
  show rating ≥ 4.0. ✅ Pass

---

### TC-08: Keyword search

- **Input:** `GET /api/items/search?keyword=Wireless`
- **Expected Output:** HTTP 200 — items whose name contains "Wireless"
  (case-insensitive).
- **Actual Output:** HTTP 200 — matches returned via
  `SearchAlgorithm.linearSearchByKeyword()`, case-insensitive confirmed. ✅ Pass

---

### TC-09: Recommendation ranking order

- **Input:** `GET /api/recommendations/1?limit=10`
- **Expected Output:** `recommendations[i].finalScore >=
  recommendations[i+1].finalScore` for every `i` (descending order after
  Merge Sort).
- **Actual Output:** Verified across multiple users — order is always
  non-increasing. ✅ Pass

---

### TC-10: Backend unavailable (frontend resilience)

- **Input:** Stop the Spring Boot backend, then open
  `recommendations.html` and click "Generate Recommendations".
- **Expected Output:** A friendly error message is shown ("Could not
  reach the backend...") — no unhandled JS exception, no blank page.
- **Actual Output:** `api.js`'s fetch wrapper catches the network error
  and `showError()` renders the friendly message inside `#rec-status`. ✅ Pass

---

### TC-11: Invalid `limit` parameter

- **Input:** `GET /api/recommendations/1?limit=0`
- **Expected Output:** HTTP 400 with a clear validation message.
- **Actual Output:** HTTP 400 —
  `{ "success": false, "status": 400, "message": "limit must be between 1 and 100." }` ✅ Pass

---

### TC-12: Statistics endpoint

- **Input:** `GET /api/statistics`
- **Expected Output:** HTTP 200 — `totalUsers`, `totalItems`,
  `totalInteractions` match the actual row counts in MySQL, plus category
  and interaction-type distributions.
- **Actual Output:** Counts match `SELECT COUNT(*)` on each table
  directly. ✅ Pass

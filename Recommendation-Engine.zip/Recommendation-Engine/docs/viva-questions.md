# Viva Preparation — 20 Questions & Answers

**1. Why did you use ArrayList instead of a plain array?**
ArrayList resizes automatically as data grows, and it comes with built-in
methods (add, remove, iterate) that make managing dynamic collections of
users, items, and interactions much simpler than manual array resizing.

**2. Why did you use HashMap for user and item lookup?**
Because HashMap gives O(1) average-case lookup by key. Instead of
scanning the whole ArrayList of 500 users every time we need one user
(O(n)), we look them up instantly by `user_id`.

**3. Why did you use HashSet to store interacted item IDs?**
A HashSet gives O(1) average membership checks (`contains()`). We use it
to instantly know whether the user has already interacted with a
candidate item, so we can skip it — this is what prevents duplicate/
already-seen recommendations.

**4. Why did you use a PriorityQueue?**
A PriorityQueue (binary heap) lets us insert every scored candidate and
always retrieve the current highest-scoring one in O(log n), without
having to sort the entire candidate list up front just to find the top
few.

**5. Why do you also apply Merge Sort if you already used a PriorityQueue?**
The PriorityQueue gives us efficient access to the top candidates, but we
extract more than we need (3×topN) and then Merge Sort guarantees a
fully stable, correctly ordered final list — and it demonstrates the
sorting algorithm requirement explicitly, as required by the course.

**6. Why Merge Sort and not Quick Sort or Collections.sort()?**
Merge Sort guarantees O(n log n) in every case — no worst-case
degradation like Quick Sort's O(n²). `Collections.sort()` is a built-in
library call; the assignment requires us to demonstrate the actual
sorting algorithm ourselves.

**7. Why do you need searching if the data is already in a HashMap?**
The HashMap is used for lookups by ID. Searching by keyword or category
(e.g., "find all items containing 'Wireless'") isn't a key lookup — it
requires scanning, so we implemented Linear Search for that, and Binary
Search for fast ID lookups on data sorted separately from the HashMap.

**8. What is the time complexity of Linear Search vs Binary Search?**
Linear Search is O(n) — it may need to check every element. Binary
Search is O(log n) but requires the data to be sorted first; we sort a
copy of the items by `item_id` before running it.

**9. Why is similarity calculation needed?**
It measures how well an item's category matches what the user actually
prefers, giving us a personalization signal beyond just "this item is
popular" — two different users see different rankings for the same
catalog.

**10. How exactly is the recommendation score calculated?**
`finalScore = 0.40×preferenceScore + 0.30×similarityScore +
0.15×ratingScore + 0.10×popularityScore + 0.05×interactionScore`. Each
component is normalized to [0,1] before weighting, so preference match
matters most, followed by category similarity, item rating, popularity,
and finally the user's own interaction signal.

**11. What is the time complexity of the overall recommendation generation?**
Roughly O(n·p + n log n): scoring every candidate item costs O(p) each
(p = number of user preferences) for n candidate items, plus O(n log n)
for the Merge Sort step at the end.

**12. What happens when a user has no history at all?**
The algorithm detects this "cold start" case and falls back to the
user's declared `preferred_category` plus item popularity/rating, so
every user still gets sensible recommendations from day one.

**13. How are duplicate recommendations avoided?**
Before scoring, every item the user has already interacted with is added
to a HashSet. Any item in that HashSet is excluded from the candidate
list entirely, so it can never be recommended again.

**14. How does the frontend communicate with the backend?**
The frontend uses the JavaScript `fetch()` API to call REST endpoints
under `http://localhost:8080/api/...` and renders the returned JSON. CORS
is explicitly configured on the backend to allow the frontend's origin
(`localhost:5500`).

**15. Why Java for this project?**
Java has first-class, well-understood implementations of ArrayList,
HashMap, HashSet, and PriorityQueue in its standard library
(`java.util`), making it a natural fit for demonstrating DSA concepts
directly, while also being a robust, statically-typed language for a
real backend service.

**16. Why Spring Boot?**
Spring Boot lets us expose the DSA logic as a REST API with minimal
boilerplate — dependency injection, embedded server, and JPA integration
all work out of the box, so we can focus on the algorithm rather than
low-level HTTP/servlet plumbing.

**17. Why MySQL instead of just using the CSV files directly?**
A relational database enforces data integrity (foreign keys ensure every
interaction references a real user and item), supports efficient
indexed queries, and mirrors how a production recommendation system
would actually store its data.

**18. What indexes did you create and why?**
Indexes on `items.category`, `items.rating`, `interactions.user_id`,
`interactions.item_id`, and `interactions.interaction_type` — these are
the columns most frequently filtered or joined on, so indexing them
speeds up exactly the queries the API relies on.

**19. How do you prevent the API from crashing on bad input?**
A `GlobalExceptionHandler` (`@RestControllerAdvice`) catches
`ResourceNotFoundException`, `IllegalArgumentException`, and any other
unhandled exception, converting them into clean JSON error responses
with appropriate HTTP status codes instead of leaking a raw Java stack
trace to the client.

**20. How would you extend this project beyond what's built?**
Add collaborative filtering (comparing users to other similar users, not
just categories), precompute and cache recommendations in the
`recommendations` table for faster repeated reads, and add real user
authentication instead of manually entering a User ID.

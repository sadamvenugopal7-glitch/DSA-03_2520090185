-- =====================================================================
-- Recommendation Engine - Database Schema
-- Course: Data Structures and Algorithms - 3 (25CS2103E)
-- Team 37 | Section 12 | KL University, Hyderabad
-- =====================================================================

DROP DATABASE IF EXISTS recommendation_engine;
CREATE DATABASE recommendation_engine;
USE recommendation_engine;

-- =====================================================================
-- TABLE: users
-- =====================================================================
CREATE TABLE users (
    user_id             INT PRIMARY KEY,
    name                VARCHAR(100) NOT NULL,
    age                 INT NOT NULL,
    gender              VARCHAR(20)  NOT NULL,
    location            VARCHAR(100) NOT NULL,
    preferred_category  VARCHAR(50)  NOT NULL,
    INDEX idx_users_category (preferred_category)
) ENGINE=InnoDB;

-- =====================================================================
-- TABLE: items
-- =====================================================================
CREATE TABLE items (
    item_id       INT PRIMARY KEY,
    item_name     VARCHAR(150) NOT NULL,
    category      VARCHAR(50)  NOT NULL,
    subcategory   VARCHAR(50)  NOT NULL,
    description   TEXT,
    rating        DECIMAL(3,1) NOT NULL DEFAULT 0,
    price         DECIMAL(10,2) NOT NULL DEFAULT 0,
    popularity    DECIMAL(6,2) NOT NULL DEFAULT 0,
    quality_score DECIMAL(4,2) NOT NULL DEFAULT 0,
    INDEX idx_items_category (category),
    INDEX idx_items_rating (rating)
) ENGINE=InnoDB;

-- =====================================================================
-- TABLE: interactions
-- =====================================================================
CREATE TABLE interactions (
    interaction_id   INT PRIMARY KEY AUTO_INCREMENT,
    user_id          INT NOT NULL,
    item_id          INT NOT NULL,
    interaction_type VARCHAR(20) NOT NULL,
    rating           DECIMAL(3,1) NULL,
    timestamp        DATETIME NOT NULL,
    CONSTRAINT fk_interactions_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_interactions_item FOREIGN KEY (item_id) REFERENCES items(item_id) ON DELETE CASCADE,
    INDEX idx_interactions_user (user_id),
    INDEX idx_interactions_item (item_id),
    INDEX idx_interactions_type (interaction_type)
) ENGINE=InnoDB;

-- =====================================================================
-- TABLE: preferences
-- =====================================================================
CREATE TABLE preferences (
    preference_id     INT PRIMARY KEY AUTO_INCREMENT,
    user_id           INT NOT NULL,
    category          VARCHAR(50) NOT NULL,
    preference_score  DECIMAL(4,2) NOT NULL,
    CONSTRAINT fk_preferences_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    UNIQUE KEY uq_user_category (user_id, category),
    INDEX idx_preferences_user (user_id)
) ENGINE=InnoDB;

-- =====================================================================
-- TABLE: recommendations  (stores generated recommendation runs, optional cache)
-- =====================================================================
CREATE TABLE recommendations (
    recommendation_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id            INT NOT NULL,
    item_id            INT NOT NULL,
    rank_position       INT NOT NULL,
    similarity_score    DECIMAL(5,4) NOT NULL,
    preference_score     DECIMAL(5,4) NOT NULL,
    final_score          DECIMAL(5,4) NOT NULL,
    generated_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_recommendations_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    CONSTRAINT fk_recommendations_item FOREIGN KEY (item_id) REFERENCES items(item_id) ON DELETE CASCADE,
    INDEX idx_recommendations_user (user_id)
) ENGINE=InnoDB;

-- =====================================================================
-- LOADING THE DATASET (run from MySQL client / Workbench)
-- Update the file path and make sure local_infile is enabled:
--   SET GLOBAL local_infile = 1;
-- =====================================================================

-- LOAD DATA LOCAL INFILE 'dataset/users.csv'
-- INTO TABLE users
-- FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\r\n'
-- IGNORE 1 ROWS
-- (user_id, name, age, gender, location, preferred_category);

-- LOAD DATA LOCAL INFILE 'dataset/items.csv'
-- INTO TABLE items
-- FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\r\n'
-- IGNORE 1 ROWS
-- (item_id, item_name, category, subcategory, description, rating, price, popularity, quality_score);

-- LOAD DATA LOCAL INFILE 'dataset/interactions.csv'
-- INTO TABLE interactions
-- FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\r\n'
-- IGNORE 1 ROWS
-- (interaction_id, user_id, item_id, interaction_type, rating, timestamp)
-- SET rating = NULLIF(rating, '');

-- LOAD DATA LOCAL INFILE 'dataset/preferences.csv'
-- INTO TABLE preferences (user_id, category, preference_score)
-- FIELDS TERMINATED BY ',' ENCLOSED BY '"' LINES TERMINATED BY '\r\n'
-- IGNORE 1 ROWS
-- (user_id, category, preference_score);

-- =====================================================================
-- SMALL SAMPLE INSERTS (so the DB has data even without CSV import)
-- =====================================================================
INSERT INTO users (user_id, name, age, gender, location, preferred_category) VALUES
(1, 'Yaswanth H', 21, 'Male', 'Hyderabad', 'Electronics'),
(2, 'Venu Gopal', 21, 'Male', 'Hyderabad', 'Gaming'),
(3, 'Ananya Sharma', 24, 'Female', 'Bengaluru', 'Books'),
(4, 'Rahul Verma', 27, 'Male', 'Mumbai', 'Sports'),
(5, 'Priya Nair', 23, 'Female', 'Chennai', 'Fashion');

INSERT INTO items (item_id, item_name, category, subcategory, description, rating, price, popularity, quality_score) VALUES
(101, 'Wireless Headphones', 'Electronics', 'Headphones', 'Premium noise-cancelling wireless headphones.', 4.7, 2999.00, 88.50, 0.92),
(102, 'Ultra Smartwatch', 'Electronics', 'Smartwatches', 'Fitness-tracking smartwatch with AMOLED display.', 4.5, 5999.00, 75.20, 0.85),
(103, 'Battle Arena Controller', 'Gaming', 'Accessories', 'Ergonomic gaming controller with RGB lighting.', 4.3, 1999.00, 60.10, 0.80),
(104, 'The Journey Novel', 'Books', 'Fiction', 'A gripping fictional journey across continents.', 4.6, 399.00, 55.30, 0.78),
(105, 'Performance Running Shoes', 'Sports', 'Running', 'Lightweight running shoes for daily training.', 4.4, 3499.00, 70.00, 0.83);

INSERT INTO preferences (user_id, category, preference_score) VALUES
(1, 'Electronics', 0.95),
(1, 'Gaming', 0.60),
(2, 'Gaming', 0.90),
(2, 'Electronics', 0.55),
(3, 'Books', 0.85);

INSERT INTO interactions (user_id, item_id, interaction_type, rating, timestamp) VALUES
(1, 102, 'view', NULL, '2026-01-05 10:15:00'),
(1, 103, 'like', NULL, '2026-01-06 11:00:00'),
(2, 103, 'purchase', 5.0, '2026-01-07 14:30:00'),
(3, 104, 'rating', 4.5, '2026-01-08 09:20:00'),
(4, 105, 'wishlist', NULL, '2026-01-09 16:45:00');

-- =====================================================================
-- USEFUL SELECT / JOIN / STATISTICS QUERIES
-- =====================================================================

-- 1. All items in a category, best rated first
SELECT item_id, item_name, rating, price
FROM items
WHERE category = 'Electronics'
ORDER BY rating DESC;

-- 2. A user's full interaction history with item details (JOIN)
SELECT i.interaction_id, u.name AS user_name, it.item_name, i.interaction_type, i.rating, i.timestamp
FROM interactions i
JOIN users u ON i.user_id = u.user_id
JOIN items it ON i.item_id = it.item_id
WHERE u.user_id = 1
ORDER BY i.timestamp DESC;

-- 3. Top 10 most popular items overall
SELECT item_id, item_name, category, popularity, rating
FROM items
ORDER BY popularity DESC
LIMIT 10;

-- 4. Category-wise average rating and item count (aggregate statistics)
SELECT category, COUNT(*) AS total_items, ROUND(AVG(rating), 2) AS avg_rating
FROM items
GROUP BY category
ORDER BY avg_rating DESC;

-- 5. Interaction type distribution (used by the dashboard chart)
SELECT interaction_type, COUNT(*) AS total
FROM interactions
GROUP BY interaction_type;

-- 6. Users who have never interacted with anything (cold-start candidates)
SELECT u.user_id, u.name
FROM users u
LEFT JOIN interactions i ON u.user_id = i.user_id
WHERE i.interaction_id IS NULL;

-- 7. Preference scores of a user joined with matching category items
SELECT p.category, p.preference_score, it.item_id, it.item_name, it.rating
FROM preferences p
JOIN items it ON it.category = p.category
WHERE p.user_id = 1
ORDER BY p.preference_score DESC, it.rating DESC;

-- 8. Overall system statistics (used by GET /api/statistics)
SELECT
  (SELECT COUNT(*) FROM users) AS total_users,
  (SELECT COUNT(*) FROM items) AS total_items,
  (SELECT COUNT(*) FROM interactions) AS total_interactions,
  (SELECT COUNT(*) FROM recommendations) AS total_recommendations_generated;

package com.recommendation.controller;

import com.recommendation.service.InteractionService;
import com.recommendation.service.ItemService;
import com.recommendation.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class StatisticsController {

    @Autowired
    private UserService userService;

    @Autowired
    private ItemService itemService;

    @Autowired
    private InteractionService interactionService;

    @GetMapping("/health")
    public Map<String, Object> health() {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("status", "UP");
        body.put("service", "Recommendation Engine API");
        body.put("timestamp", java.time.LocalDateTime.now().toString());
        return body;
    }

    @GetMapping("/statistics")
    public Map<String, Object> statistics() {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("totalUsers", userService.countUsers());
        body.put("totalItems", itemService.countItems());
        body.put("totalInteractions", interactionService.countInteractions());
        body.put("categoryDistribution", categoryDistribution());
        body.put("interactionTypeDistribution", interactionTypeDistribution());
        return body;
    }

    private Map<String, Long> categoryDistribution() {
        Map<String, Long> distribution = new LinkedHashMap<>();
        itemService.getAllItems().forEach(item ->
                distribution.merge(item.getCategory(), 1L, Long::sum));
        return distribution;
    }

    private Map<String, Long> interactionTypeDistribution() {
        Map<String, Long> distribution = new LinkedHashMap<>();
        interactionService.getAllInteractions().forEach(interaction ->
                distribution.merge(interaction.getInteractionType(), 1L, Long::sum));
        return distribution;
    }
}

package com.recommendation.model;

/**
 * Represents one recommended item for a user, carrying every score
 * component used to compute the final ranking.
 *
 * Implements Comparable so instances can be inserted directly into a
 * java.util.PriorityQueue that always keeps the highest finalScore
 * at the head (a max-heap behaviour, achieved via reverse ordering).
 */
public class Recommendation implements Comparable<Recommendation> {

    private int rank;
    private Integer itemId;
    private String itemName;
    private String category;
    private Double rating;
    private Double price;
    private double similarityScore;
    private double preferenceScore;
    private double ratingScore;
    private double popularityScore;
    private double interactionScore;
    private double finalScore;

    public Recommendation() {
    }

    public Recommendation(Integer itemId, String itemName, String category, Double rating, Double price,
                           double similarityScore, double preferenceScore, double ratingScore,
                           double popularityScore, double interactionScore, double finalScore) {
        this.itemId = itemId;
        this.itemName = itemName;
        this.category = category;
        this.rating = rating;
        this.price = price;
        this.similarityScore = similarityScore;
        this.preferenceScore = preferenceScore;
        this.ratingScore = ratingScore;
        this.popularityScore = popularityScore;
        this.interactionScore = interactionScore;
        this.finalScore = finalScore;
    }

    /**
     * PriorityQueue in Java is a MIN-heap by default (smallest element at
     * the head). Because we want the item with the HIGHEST finalScore to
     * come out first, we reverse the natural ordering here: a Recommendation
     * with a larger finalScore is considered "smaller" so it rises to the
     * head of the queue.
     */
    @Override
    public int compareTo(Recommendation other) {
        return Double.compare(other.finalScore, this.finalScore);
    }

    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    public Integer getItemId() {
        return itemId;
    }

    public void setItemId(Integer itemId) {
        this.itemId = itemId;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Double getRating() {
        return rating;
    }

    public void setRating(Double rating) {
        this.rating = rating;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public double getSimilarityScore() {
        return similarityScore;
    }

    public void setSimilarityScore(double similarityScore) {
        this.similarityScore = similarityScore;
    }

    public double getPreferenceScore() {
        return preferenceScore;
    }

    public void setPreferenceScore(double preferenceScore) {
        this.preferenceScore = preferenceScore;
    }

    public double getRatingScore() {
        return ratingScore;
    }

    public void setRatingScore(double ratingScore) {
        this.ratingScore = ratingScore;
    }

    public double getPopularityScore() {
        return popularityScore;
    }

    public void setPopularityScore(double popularityScore) {
        this.popularityScore = popularityScore;
    }

    public double getInteractionScore() {
        return interactionScore;
    }

    public void setInteractionScore(double interactionScore) {
        this.interactionScore = interactionScore;
    }

    public double getFinalScore() {
        return finalScore;
    }

    public void setFinalScore(double finalScore) {
        this.finalScore = finalScore;
    }
}

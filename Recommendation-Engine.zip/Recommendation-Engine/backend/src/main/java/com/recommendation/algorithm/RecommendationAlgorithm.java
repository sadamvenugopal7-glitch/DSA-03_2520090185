package com.recommendation.algorithm;

import com.recommendation.model.Interaction;
import com.recommendation.model.Item;
import com.recommendation.model.Preference;
import com.recommendation.model.Recommendation;
import com.recommendation.model.User;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.PriorityQueue;

/**
 * The heart of the DSA-3 project: generates ranked, personalized
 * recommendations for a user by combining ArrayList, HashMap, HashSet,
 * PriorityQueue, manual searching, manual sorting and similarity scoring.
 *
 * Algorithm steps (matches the project specification):
 *  1.  Receive user ID.
 *  2.  Find user using HashMap.               -> O(1)
 *  3.  Find user's preferences.
 *  4.  Find user's interaction history.
 *  5.  Store previously interacted item IDs in HashSet.  -> O(1) lookups
 *  6.  Search candidate items (linear search over ArrayList).
 *  7.  Calculate similarity.
 *  8.  Calculate preference score.
 *  9.  Calculate rating score.
 *  10. Calculate popularity score.
 *  11. Calculate interaction score.
 *  12. Calculate final score (weighted sum).
 *  13. Insert recommendations into PriorityQueue.  -> O(log n) insertion
 *  14. Extract highest-ranked recommendations.     -> O(log n) removal
 *  15. Apply Merge Sort to the extracted candidates for a stable final order.
 *  16. Return Top-N recommendations.
 */
public class RecommendationAlgorithm {

    // Weights for the final recommendation score (must sum to 1.0)
    private static final double W_PREFERENCE = 0.40;
    private static final double W_SIMILARITY = 0.30;
    private static final double W_RATING = 0.15;
    private static final double W_POPULARITY = 0.10;
    private static final double W_INTERACTION = 0.05;

    /**
     * Generates the Top-N recommendations for a single user.
     *
     * @param userId          the target user's ID
     * @param allUsers        ArrayList of all users (source data)
     * @param allItems        ArrayList of all items (source data)
     * @param allInteractions ArrayList of all interactions (source data)
     * @param allPreferences  ArrayList of all preferences (source data)
     * @param topN            number of recommendations to return
     */
    public static ArrayList<Recommendation> generateRecommendations(
            int userId,
            ArrayList<User> allUsers,
            ArrayList<Item> allItems,
            ArrayList<Interaction> allInteractions,
            ArrayList<Preference> allPreferences,
            int topN) {

        // Step 2: HashMap for O(1) user lookup
        HashMap<Integer, User> userMap = new HashMap<>();
        for (User u : allUsers) {
            userMap.put(u.getUserId(), u);
        }
        User targetUser = userMap.get(userId);
        if (targetUser == null) {
            return new ArrayList<>();
        }

        // HashMap for O(1) item lookup
        HashMap<Integer, Item> itemMap = new HashMap<>();
        for (Item item : allItems) {
            itemMap.put(item.getItemId(), item);
        }

        // Step 3: user's preferences
        ArrayList<Preference> userPreferences = new ArrayList<>();
        HashSet<String> preferredCategories = new HashSet<>();
        HashMap<String, Double> categoryBestScore = new HashMap<>();
        for (Preference p : allPreferences) {
            if (p.getUserId().equals(userId)) {
                userPreferences.add(p);
                preferredCategories.add(p.getCategory());
                categoryBestScore.merge(p.getCategory(), p.getPreferenceScore(), Math::max);
            }
        }

        // Step 4: user's interaction history
        ArrayList<Interaction> userInteractions = new ArrayList<>();
        for (Interaction i : allInteractions) {
            if (i.getUserId().equals(userId)) {
                userInteractions.add(i);
            }
        }

        // Step 5: HashSet of already-interacted item IDs (prevents duplicate recs)
        HashSet<Integer> interactedItemIds = new HashSet<>();
        // HashMap: itemId -> interaction weight (counts + purchase/like boost)
        HashMap<Integer, Double> interactionWeight = new HashMap<>();
        for (Interaction i : userInteractions) {
            interactedItemIds.add(i.getItemId());
            double weight = switch (i.getInteractionType()) {
                case "purchase" -> 1.0;
                case "like" -> 0.7;
                case "wishlist" -> 0.6;
                case "rating" -> 0.5;
                case "click" -> 0.3;
                default -> 0.1; // view
            };
            interactionWeight.merge(i.getItemId(), weight, Double::sum);
        }

        // HashSet of unique categories across the catalog (used for stats/coverage)
        HashSet<String> allCategories = new HashSet<>();
        for (Item item : allItems) {
            allCategories.add(item.getCategory());
        }

        // Step 6: candidate items = all items the user has NOT already interacted with
        // (a linear search / filter pass over the ArrayList of items)
        ArrayList<Item> candidateItems = new ArrayList<>();
        for (Item item : allItems) {
            if (!interactedItemIds.contains(item.getItemId())) {
                candidateItems.add(item);
            }
        }

        // Determine max popularity for normalization
        double maxPopularity = 1.0;
        for (Item item : allItems) {
            if (item.getPopularity() != null && item.getPopularity() > maxPopularity) {
                maxPopularity = item.getPopularity();
            }
        }

        boolean coldStart = userPreferences.isEmpty() && userInteractions.isEmpty();

        // Steps 7-12: score every candidate
        PriorityQueue<Recommendation> recommendationQueue = new PriorityQueue<>();

        for (Item item : candidateItems) {
            double similarityScore;
            double preferenceScore;

            if (coldStart) {
                // Step: cold-start fallback -> use the user's declared
                // preferred_category and item popularity only.
                boolean matchesPreferredCategory =
                        targetUser.getPreferredCategory() != null &&
                        targetUser.getPreferredCategory().equalsIgnoreCase(item.getCategory());
                similarityScore = matchesPreferredCategory ? 0.8 : 0.2;
                preferenceScore = matchesPreferredCategory ? 0.9 : 0.3;
            } else {
                similarityScore = SimilarityCalculator.calculateSimilarity(userPreferences, item);
                Double bestScore = categoryBestScore.getOrDefault(item.getCategory(), 0.0);
                preferenceScore = SimilarityCalculator.calculateSimilarityFast(
                        preferredCategories, bestScore, item);
            }

            double ratingScore = (item.getRating() == null) ? 0.0 : item.getRating() / 5.0;
            double popularityScore = (item.getPopularity() == null) ? 0.0 : item.getPopularity() / maxPopularity;
            double interactionScore = normalizeInteraction(interactionWeight.getOrDefault(item.getItemId(), 0.0));

            double finalScore =
                    (W_PREFERENCE * preferenceScore) +
                    (W_SIMILARITY * similarityScore) +
                    (W_RATING * ratingScore) +
                    (W_POPULARITY * popularityScore) +
                    (W_INTERACTION * interactionScore);

            Recommendation rec = new Recommendation(
                    item.getItemId(), item.getItemName(), item.getCategory(),
                    item.getRating(), item.getPrice(),
                    round4(similarityScore), round4(preferenceScore), round4(ratingScore),
                    round4(popularityScore), round4(interactionScore), round4(finalScore));

            // Step 13: insert into PriorityQueue (max-heap by finalScore)
            recommendationQueue.offer(rec);
        }

        // Step 14: extract the highest-ranked candidates (more than topN so
        // that the subsequent sort step has a meaningful list to work with)
        int extractCount = Math.min(recommendationQueue.size(), Math.max(topN * 3, topN));
        ArrayList<Recommendation> extracted = new ArrayList<>();
        for (int i = 0; i < extractCount && !recommendationQueue.isEmpty(); i++) {
            extracted.add(recommendationQueue.poll());
        }

        // Step 15: apply Merge Sort for the final, stable descending order
        SortingAlgorithm.mergeSort(extracted);

        // Step 16: return Top-N with rank assigned
        ArrayList<Recommendation> topResults = new ArrayList<>();
        for (int i = 0; i < Math.min(topN, extracted.size()); i++) {
            Recommendation r = extracted.get(i);
            r.setRank(i + 1);
            topResults.add(r);
        }

        return topResults;
    }

    private static double normalizeInteraction(double rawWeight) {
        // Cap at 1.0 - a user could have multiple interactions with an item type
        return Math.min(rawWeight, 1.0);
    }

    private static double round4(double value) {
        return Math.round(value * 10000.0) / 10000.0;
    }
}

package com.recommendation.algorithm;

import com.recommendation.model.Recommendation;

import java.util.ArrayList;

/**
 * Manual Merge Sort implementation.
 *
 * Used to sort the extracted recommendation candidates by finalScore
 * in descending order, as the final ranking step before returning the
 * Top-N recommendations to the caller.
 *
 * Time Complexity:  O(n log n)  in all cases (best, average, worst)
 * Space Complexity: O(n)        (auxiliary arrays used while merging)
 *
 * Merge Sort is preferred over simple O(n^2) sorts (bubble/insertion) or
 * Collections.sort() because it demonstrates the divide-and-conquer
 * paradigm explicitly, which is required for the DSA-3 evaluation.
 */
public class SortingAlgorithm {

    /**
     * Sorts the given list of recommendations by finalScore, descending.
     */
    public static void mergeSort(ArrayList<Recommendation> list) {
        if (list.size() <= 1) {
            return;
        }
        Recommendation[] array = list.toArray(new Recommendation[0]);
        Recommendation[] temp = new Recommendation[array.length];
        mergeSort(array, temp, 0, array.length - 1);

        list.clear();
        for (Recommendation r : array) {
            list.add(r);
        }
    }

    private static void mergeSort(Recommendation[] array, Recommendation[] temp, int left, int right) {
        if (left >= right) {
            return;
        }
        int mid = left + (right - left) / 2;
        mergeSort(array, temp, left, mid);
        mergeSort(array, temp, mid + 1, right);
        merge(array, temp, left, mid, right);
    }

    private static void merge(Recommendation[] array, Recommendation[] temp, int left, int mid, int right) {
        for (int i = left; i <= right; i++) {
            temp[i] = array[i];
        }

        int i = left;
        int j = mid + 1;
        int k = left;

        while (i <= mid && j <= right) {
            // Descending order: higher finalScore comes first
            if (temp[i].getFinalScore() >= temp[j].getFinalScore()) {
                array[k] = temp[i];
                i++;
            } else {
                array[k] = temp[j];
                j++;
            }
            k++;
        }

        while (i <= mid) {
            array[k] = temp[i];
            i++;
            k++;
        }

        while (j <= right) {
            array[k] = temp[j];
            j++;
            k++;
        }
    }
}

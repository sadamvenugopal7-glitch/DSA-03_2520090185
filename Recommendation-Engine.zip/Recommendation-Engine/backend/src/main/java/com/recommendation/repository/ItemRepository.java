package com.recommendation.repository;

import com.recommendation.model.Item;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ItemRepository extends JpaRepository<Item, Integer> {

    List<Item> findByCategoryIgnoreCase(String category);
}

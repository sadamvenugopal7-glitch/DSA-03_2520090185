package com.recommendation.repository;

import com.recommendation.model.Preference;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PreferenceRepository extends JpaRepository<Preference, Integer> {

    List<Preference> findByUserId(Integer userId);
}

package com.recommendation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Entry point of the Recommendation Engine Spring Boot application.
 *
 * DSA-3 Project | Team 37 | Section 12
 * Team Members: Yaswanth H (2520090095), Venu Gopal (2520090185)
 * Guide: Chandusha Kanda | KL University, Hyderabad
 */
@SpringBootApplication
public class RecommendationEngineApplication {

    public static void main(String[] args) {
        SpringApplication.run(RecommendationEngineApplication.class, args);
        System.out.println("=================================================");
        System.out.println(" Recommendation Engine backend started on :8080");
        System.out.println(" Health check: http://localhost:8080/api/health");
        System.out.println("=================================================");
    }
}

package com.recommendation.service;

import com.recommendation.algorithm.RecommendationAlgorithm;
import com.recommendation.model.Interaction;
import com.recommendation.model.Item;
import com.recommendation.model.Preference;
import com.recommendation.model.Recommendation;
import com.recommendation.model.User;
import com.recommendation.repository.InteractionRepository;
import com.recommendation.repository.ItemRepository;
import com.recommendation.repository.PreferenceRepository;
import com.recommendation.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class RecommendationService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ItemRepository itemRepository;

    @Autowired
    private InteractionRepository interactionRepository;

    @Autowired
    private PreferenceRepository preferenceRepository;

    /**
     * Loads all source data into ArrayLists and delegates to the
     * RecommendationAlgorithm (which internally uses HashMap, HashSet,
     * PriorityQueue, manual search and merge sort).
     */
    public ArrayList<Recommendation> getRecommendations(int userId, int topN) {
        ArrayList<User> users = new ArrayList<>(userRepository.findAll());
        ArrayList<Item> items = new ArrayList<>(itemRepository.findAll());
        ArrayList<Interaction> interactions = new ArrayList<>(interactionRepository.findAll());
        ArrayList<Preference> preferences = new ArrayList<>(preferenceRepository.findAll());

        return RecommendationAlgorithm.generateRecommendations(
                userId, users, items, interactions, preferences, topN);
    }

    public boolean userExists(int userId) {
        return userRepository.existsById(userId);
    }
}

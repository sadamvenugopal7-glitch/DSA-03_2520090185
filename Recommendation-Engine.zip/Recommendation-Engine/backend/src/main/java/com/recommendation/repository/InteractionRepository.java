package com.recommendation.repository;

import com.recommendation.model.Interaction;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface InteractionRepository extends JpaRepository<Interaction, Integer> {

    List<Interaction> findByUserId(Integer userId);
}

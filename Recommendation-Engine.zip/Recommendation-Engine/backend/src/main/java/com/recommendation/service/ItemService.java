package com.recommendation.service;

import com.recommendation.algorithm.SearchAlgorithm;
import com.recommendation.model.Item;
import com.recommendation.repository.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Optional;

@Service
public class ItemService {

    @Autowired
    private ItemRepository itemRepository;

    public ArrayList<Item> getAllItems() {
        return new ArrayList<>(itemRepository.findAll());
    }

    public Optional<Item> getItemById(Integer id) {
        return itemRepository.findById(id);
    }

    /** Uses the manually implemented linear search (SearchAlgorithm) rather than a JPA query. */
    public Item findByIdUsingLinearSearch(Integer id) {
        ArrayList<Item> all = getAllItems();
        return SearchAlgorithm.linearSearch(all, id);
    }

    /** Uses the manually implemented binary search (SearchAlgorithm) - list is sorted first. */
    public Item findByIdUsingBinarySearch(Integer id) {
        ArrayList<Item> all = getAllItems();
        ArrayList<Item> sorted = SearchAlgorithm.prepareForBinarySearch(all);
        return SearchAlgorithm.binarySearch(sorted, id);
    }

    public ArrayList<Item> searchByKeyword(String keyword) {
        return SearchAlgorithm.linearSearchByKeyword(getAllItems(), keyword);
    }

    public ArrayList<Item> getByCategory(String category) {
        return SearchAlgorithm.linearSearchByCategory(getAllItems(), category);
    }

    public long countItems() {
        return itemRepository.count();
    }
}

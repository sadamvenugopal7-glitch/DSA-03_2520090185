package com.recommendation.controller;

import com.recommendation.config.ResourceNotFoundException;
import com.recommendation.model.Recommendation;
import com.recommendation.service.RecommendationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/recommendations")
public class RecommendationController {

    @Autowired
    private RecommendationService recommendationService;

    @GetMapping("/{userId}")
    public Map<String, Object> getRecommendations(
            @PathVariable Integer userId,
            @RequestParam(defaultValue = "10") Integer limit) {

        if (!recommendationService.userExists(userId)) {
            throw new ResourceNotFoundException("User with ID " + userId + " was not found.");
        }
        if (limit <= 0 || limit > 100) {
            throw new IllegalArgumentException("limit must be between 1 and 100.");
        }

        ArrayList<Recommendation> recommendations = recommendationService.getRecommendations(userId, limit);

        Map<String, Object> response = new LinkedHashMap<>();
        response.put("userId", userId);
        response.put("count", recommendations.size());
        response.put("recommendations", recommendations);

        if (recommendations.isEmpty()) {
            response.put("message", "No recommendations available for this user yet.");
        }

        return response;
    }
}

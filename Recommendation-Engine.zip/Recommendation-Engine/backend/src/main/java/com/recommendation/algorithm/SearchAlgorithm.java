package com.recommendation.algorithm;

import com.recommendation.model.Item;

import java.util.ArrayList;
import java.util.Comparator;

/**
 * Manual implementations of Linear Search and Binary Search over item data.
 *
 * Time Complexity:
 *  - linearSearch():  O(n)      -> checks every element in the worst case.
 *  - binarySearch():  O(log n)  -> halves the search space each iteration,
 *                                  but REQUIRES the list to be sorted first.
 */
public class SearchAlgorithm {

    /**
     * Linear Search - scans the list sequentially until the target itemId
     * is found or the end of the list is reached.
     * Time Complexity: O(n)
     * Space Complexity: O(1)
     */
    public static Item linearSearch(ArrayList<Item> items, int itemId) {
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).getItemId() == itemId) {
                return items.get(i);
            }
        }
        return null;
    }

    /**
     * Binary Search - requires the ArrayList to already be sorted by
     * itemId (ascending). Repeatedly halves the search interval.
     * Time Complexity: O(log n)
     * Space Complexity: O(1)
     */
    public static Item binarySearch(ArrayList<Item> sortedItemsById, int itemId) {
        int low = 0;
        int high = sortedItemsById.size() - 1;

        while (low <= high) {
            int mid = low + (high - low) / 2;
            Item midItem = sortedItemsById.get(mid);

            if (midItem.getItemId() == itemId) {
                return midItem;
            } else if (midItem.getItemId() < itemId) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }
        return null;
    }

    /**
     * Linear search for all items in a given category.
     * Time Complexity: O(n)
     */
    public static ArrayList<Item> linearSearchByCategory(ArrayList<Item> items, String category) {
        ArrayList<Item> result = new ArrayList<>();
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).getCategory().equalsIgnoreCase(category)) {
                result.add(items.get(i));
            }
        }
        return result;
    }

    /**
     * Linear search for items whose name contains the given keyword
     * (case-insensitive substring match).
     * Time Complexity: O(n * m) where m is average string length.
     */
    public static ArrayList<Item> linearSearchByKeyword(ArrayList<Item> items, String keyword) {
        ArrayList<Item> result = new ArrayList<>();
        String lowerKeyword = keyword.toLowerCase();
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).getItemName().toLowerCase().contains(lowerKeyword)) {
                result.add(items.get(i));
            }
        }
        return result;
    }

    /** Helper: sorts a copy of the list by itemId ascending (needed before binarySearch). */
    public static ArrayList<Item> prepareForBinarySearch(ArrayList<Item> items) {
        ArrayList<Item> copy = new ArrayList<>(items);
        copy.sort(Comparator.comparingInt(Item::getItemId));
        return copy;
    }
}

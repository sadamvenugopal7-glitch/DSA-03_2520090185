package com.recommendation.controller;

import com.recommendation.model.Interaction;
import com.recommendation.service.InteractionService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/interactions")
public class InteractionController {

    @Autowired
    private InteractionService interactionService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Interaction addInteraction(@Valid @RequestBody Interaction interaction) {
        if (interaction.getTimestamp() == null) {
            interaction.setTimestamp(java.time.LocalDateTime.now());
        }
        return interactionService.addInteraction(interaction);
    }
}

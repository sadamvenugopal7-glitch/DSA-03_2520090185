package com.recommendation.controller;

import com.recommendation.config.ResourceNotFoundException;
import com.recommendation.model.Item;
import com.recommendation.service.ItemService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
@RequestMapping("/api")
public class ItemController {

    @Autowired
    private ItemService itemService;

    @GetMapping("/items")
    public ArrayList<Item> getAllItems() {
        return itemService.getAllItems();
    }

    @GetMapping("/items/{id}")
    public Item getItemById(@PathVariable Integer id) {
        Item item = itemService.findByIdUsingBinarySearch(id);
        if (item == null) {
            throw new ResourceNotFoundException("Item with ID " + id + " was not found.");
        }
        return item;
    }

    @GetMapping("/items/search")
    public ArrayList<Item> searchItems(@RequestParam String keyword) {
        return itemService.searchByKeyword(keyword);
    }

    @GetMapping("/items/category/{category}")
    public ArrayList<Item> getItemsByCategory(@PathVariable String category) {
        return itemService.getByCategory(category);
    }
}

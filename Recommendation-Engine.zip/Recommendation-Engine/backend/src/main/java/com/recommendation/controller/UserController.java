package com.recommendation.controller;

import com.recommendation.config.ResourceNotFoundException;
import com.recommendation.model.Interaction;
import com.recommendation.model.User;
import com.recommendation.service.InteractionService;
import com.recommendation.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

    @Autowired
    private InteractionService interactionService;

    @GetMapping
    public ArrayList<User> getAllUsers() {
        return userService.getAllUsers();
    }

    @GetMapping("/{id}")
    public User getUserById(@PathVariable Integer id) {
        return userService.getUserById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User with ID " + id + " was not found."));
    }

    @GetMapping("/{id}/history")
    public ArrayList<Interaction> getUserHistory(@PathVariable Integer id) {
        if (!userService.existsById(id)) {
            throw new ResourceNotFoundException("User with ID " + id + " was not found.");
        }
        return interactionService.getHistoryForUser(id);
    }
}

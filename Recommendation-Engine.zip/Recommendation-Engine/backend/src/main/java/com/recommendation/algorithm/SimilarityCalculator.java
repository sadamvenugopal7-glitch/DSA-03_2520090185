package com.recommendation.algorithm;

import com.recommendation.model.Item;
import com.recommendation.model.Preference;

import java.util.HashSet;
import java.util.List;

/**
 * Calculates a similarity score between a user's stated preferences and a
 * candidate item, based on category matching.
 *
 * Formula (kept simple and explainable for the viva):
 *
 *   similarityScore = matchingPreferences / totalPreferences
 *
 * Where:
 *   - totalPreferences    = number of distinct categories the user has
 *                            expressed a preference for.
 *   - matchingPreferences = 1 if the item's category is among the user's
 *                            preferred categories, weighted by how strong
 *                            that preference is (preference_score),
 *                            else 0.
 *
 * The result is always normalized to the range [0, 1].
 */
public class SimilarityCalculator {

    /**
     * Computes similarity between a user's preference list and a single item.
     * Time Complexity: O(p) where p = number of preferences for the user
     * (a HashSet lookup would make category membership O(1), so for larger
     * preference lists a HashSet index is used - see calculateWithIndex()).
     */
    public static double calculateSimilarity(List<Preference> userPreferences, Item item) {
        if (userPreferences == null || userPreferences.isEmpty()) {
            return 0.0;
        }

        double matchScore = 0.0;
        int totalPreferences = userPreferences.size();

        for (Preference pref : userPreferences) {
            if (pref.getCategory().equalsIgnoreCase(item.getCategory())) {
                matchScore += pref.getPreferenceScore();
            }
        }

        double similarity = matchScore / totalPreferences;

        // Bonus: subcategory keyword overlap with description adds a small boost
        if (item.getDescription() != null &&
                item.getDescription().toLowerCase().contains(item.getSubcategory().toLowerCase())) {
            similarity += 0.05;
        }

        return normalize(similarity);
    }

    /**
     * Faster variant using a HashSet of the user's preferred categories for
     * O(1) average-case membership checks instead of scanning the list.
     * Time Complexity: O(1) average, after the O(p) HashSet is built once.
     */
    public static double calculateSimilarityFast(HashSet<String> preferredCategories,
                                                  double bestMatchingPreferenceScore,
                                                  Item item) {
        if (preferredCategories == null || preferredCategories.isEmpty()) {
            return 0.0;
        }
        boolean matches = preferredCategories.contains(item.getCategory());
        double similarity = matches ? bestMatchingPreferenceScore : 0.0;
        return normalize(similarity);
    }

    private static double normalize(double value) {
        if (value < 0) return 0.0;
        if (value > 1) return 1.0;
        return value;
    }
}

package com.recommendation.service;

import com.recommendation.model.User;
import com.recommendation.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public ArrayList<User> getAllUsers() {
        return new ArrayList<>(userRepository.findAll());
    }

    public Optional<User> getUserById(Integer id) {
        return userRepository.findById(id);
    }

    public User createOrUpdateUser(User user) {
        return userRepository.save(user);
    }

    public boolean existsById(Integer id) {
        return userRepository.existsById(id);
    }

    public long countUsers() {
        return userRepository.count();
    }
}

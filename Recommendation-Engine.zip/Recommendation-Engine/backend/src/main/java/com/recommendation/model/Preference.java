package com.recommendation.model;

import jakarta.persistence.*;

@Entity
@Table(name = "preferences")
public class Preference {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "preference_id")
    private Integer preferenceId;

    @Column(name = "user_id", nullable = false)
    private Integer userId;

    @Column(nullable = false, length = 50)
    private String category;

    @Column(name = "preference_score", nullable = false)
    private Double preferenceScore;

    public Preference() {
    }

    public Preference(Integer userId, String category, Double preferenceScore) {
        this.userId = userId;
        this.category = category;
        this.preferenceScore = preferenceScore;
    }

    public Integer getPreferenceId() {
        return preferenceId;
    }

    public void setPreferenceId(Integer preferenceId) {
        this.preferenceId = preferenceId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Double getPreferenceScore() {
        return preferenceScore;
    }

    public void setPreferenceScore(Double preferenceScore) {
        this.preferenceScore = preferenceScore;
    }
}

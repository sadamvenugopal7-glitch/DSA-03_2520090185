package com.recommendation.service;

import com.recommendation.model.Interaction;
import com.recommendation.repository.InteractionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class InteractionService {

    @Autowired
    private InteractionRepository interactionRepository;

    public ArrayList<Interaction> getAllInteractions() {
        return new ArrayList<>(interactionRepository.findAll());
    }

    public ArrayList<Interaction> getHistoryForUser(Integer userId) {
        return new ArrayList<>(interactionRepository.findByUserId(userId));
    }

    public Interaction addInteraction(Interaction interaction) {
        return interactionRepository.save(interaction);
    }

    public long countInteractions() {
        return interactionRepository.count();
    }
}

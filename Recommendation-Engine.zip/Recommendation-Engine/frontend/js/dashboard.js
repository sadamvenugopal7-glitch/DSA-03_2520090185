document.addEventListener("DOMContentLoaded", loadDashboard);

async function loadDashboard() {
  const statusEl = document.getElementById("stats-status");
  const cardsEl = document.getElementById("stat-cards");
  showLoading(statusEl, "Fetching live statistics from the backend...");

  try {
    const [stats, items] = await Promise.all([Api.getStatistics(), Api.getItems()]);
    statusEl.innerHTML = "";

    cardsEl.innerHTML = `
      <div class="card stat-card">
        <div class="value">${stats.totalUsers}</div>
        <div class="label">Total Users</div>
      </div>
      <div class="card stat-card">
        <div class="value">${stats.totalItems}</div>
        <div class="label">Total Items</div>
      </div>
      <div class="card stat-card">
        <div class="value">${stats.totalInteractions}</div>
        <div class="label">Total Interactions</div>
      </div>
      <div class="card stat-card">
        <div class="value">${Object.keys(stats.categoryDistribution || {}).length}</div>
        <div class="label">Categories Covered</div>
      </div>
    `;

    renderCategoryChart(stats.categoryDistribution || {});
    renderInteractionChart(stats.interactionTypeDistribution || {});
    renderRatingChart(items || []);
  } catch (err) {
    showError(statusEl, err);
    cardsEl.innerHTML = "";
  }
}

function renderCategoryChart(distribution) {
  const ctx = document.getElementById("categoryChart");
  new Chart(ctx, {
    type: "doughnut",
    data: {
      labels: Object.keys(distribution),
      datasets: [{
        data: Object.values(distribution),
        backgroundColor: ["#3b82f6","#60a5fa","#6366f1","#a78bfa","#22c55e","#f59e0b","#ef4444","#14b8a6","#eab308","#ec4899"],
        borderWidth: 0,
      }],
    },
    options: {
      plugins: { legend: { labels: { color: "#e5edff" } } },
    },
  });
}

function renderInteractionChart(distribution) {
  const ctx = document.getElementById("interactionChart");
  new Chart(ctx, {
    type: "bar",
    data: {
      labels: Object.keys(distribution),
      datasets: [{
        label: "Count",
        data: Object.values(distribution),
        backgroundColor: "#3b82f6",
        borderRadius: 6,
      }],
    },
    options: {
      plugins: { legend: { display: false } },
      scales: {
        x: { ticks: { color: "#93a4c3" }, grid: { color: "#22304f" } },
        y: { ticks: { color: "#93a4c3" }, grid: { color: "#22304f" } },
      },
    },
  });
}

function renderRatingChart(items) {
  const buckets = { "1-2": 0, "2-3": 0, "3-4": 0, "4-5": 0 };
  items.forEach((item) => {
    const r = item.rating || 0;
    if (r < 2) buckets["1-2"]++;
    else if (r < 3) buckets["2-3"]++;
    else if (r < 4) buckets["3-4"]++;
    else buckets["4-5"]++;
  });

  const ctx = document.getElementById("ratingChart");
  new Chart(ctx, {
    type: "line",
    data: {
      labels: Object.keys(buckets),
      datasets: [{
        label: "Items",
        data: Object.values(buckets),
        borderColor: "#60a5fa",
        backgroundColor: "rgba(59,130,246,0.2)",
        fill: true,
        tension: 0.35,
      }],
    },
    options: {
      plugins: { legend: { labels: { color: "#e5edff" } } },
      scales: {
        x: { ticks: { color: "#93a4c3" }, grid: { color: "#22304f" } },
        y: { ticks: { color: "#93a4c3" }, grid: { color: "#22304f" } },
      },
    },
  });
}

// =====================================================================
// api.js - central API client for the Recommendation Engine frontend
// =====================================================================

const API_BASE_URL = "http://localhost:8080/api";

/**
 * Generic fetch wrapper with timeout + friendly error handling.
 */
async function apiRequest(path, options = {}) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 8000);

  try {
    const response = await fetch(`${API_BASE_URL}${path}`, {
      headers: { "Content-Type": "application/json" },
      signal: controller.signal,
      ...options,
    });
    clearTimeout(timeoutId);

    if (!response.ok) {
      let message = `Request failed (${response.status})`;
      try {
        const errorBody = await response.json();
        if (errorBody && errorBody.message) message = errorBody.message;
      } catch (_) { /* ignore parse errors */ }
      throw new ApiError(message, response.status);
    }

    if (response.status === 204) return null;
    return await response.json();
  } catch (err) {
    clearTimeout(timeoutId);
    if (err.name === "AbortError") {
      throw new ApiError("The backend took too long to respond. Is it running?", 0);
    }
    if (err instanceof ApiError) throw err;
    throw new ApiError("Could not reach the backend. Make sure the Spring Boot server is running on port 8080.", 0);
  }
}

class ApiError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

const Api = {
  getUsers: () => apiRequest("/users"),
  getUser: (id) => apiRequest(`/users/${id}`),
  getItems: () => apiRequest("/items"),
  getItem: (id) => apiRequest(`/items/${id}`),
  getRecommendations: (userId, limit = 10) =>
    apiRequest(`/recommendations/${userId}?limit=${limit}`),
  getHistory: (userId) => apiRequest(`/users/${userId}/history`),
  addInteraction: (data) =>
    apiRequest("/interactions", { method: "POST", body: JSON.stringify(data) }),
  getStatistics: () => apiRequest("/statistics"),
  searchItems: (keyword) => apiRequest(`/items/search?keyword=${encodeURIComponent(keyword)}`),
  getItemsByCategory: (category) => apiRequest(`/items/category/${encodeURIComponent(category)}`),
  healthCheck: () => apiRequest("/health"),
};

/** Renders a loading message inside a container element. */
function showLoading(container, text = "Loading...") {
  container.innerHTML = `<div class="msg msg-loading">${text}</div>`;
}

/** Renders a friendly error message inside a container element. */
function showError(container, err) {
  const text = err && err.message ? err.message : "Something went wrong.";
  container.innerHTML = `<div class="msg msg-error">⚠ ${text}</div>`;
}

/** Renders an empty-state message inside a container element. */
function showEmpty(container, text = "No data available.") {
  container.innerHTML = `<div class="msg msg-empty">${text}</div>`;
}

document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("loadHistoryBtn").addEventListener("click", loadHistory);
  loadHistory();
});

async function loadHistory() {
  const statusEl = document.getElementById("history-status");
  const table = document.getElementById("history-table");
  const body = document.getElementById("history-body");
  const userId = document.getElementById("historyUserId").value;

  if (!userId || userId < 1) {
    showError(statusEl, new Error("Please enter a valid User ID."));
    table.style.display = "none";
    return;
  }

  showLoading(statusEl, `Loading history for user #${userId}...`);
  table.style.display = "none";

  try {
    const [history, user, items] = await Promise.all([
      Api.getHistory(userId),
      Api.getUser(userId),
      Api.getItems(),
    ]);

    if (!history || history.length === 0) {
      showEmpty(statusEl, `${user.name} has no recorded interactions yet.`);
      return;
    }

    const itemMap = {};
    items.forEach((item) => (itemMap[item.itemId] = item.itemName));

    statusEl.innerHTML = "";
    body.innerHTML = history
      .sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))
      .map(
        (h) => `
      <tr>
        <td>${h.interactionId}</td>
        <td>${user.name}</td>
        <td>${itemMap[h.itemId] || "Item #" + h.itemId}</td>
        <td>${h.interactionType}</td>
        <td>${h.rating ?? "-"}</td>
        <td>${new Date(h.timestamp).toLocaleString()}</td>
      </tr>
    `
      )
      .join("");
    table.style.display = "table";
  } catch (err) {
    showError(statusEl, err);
  }
}

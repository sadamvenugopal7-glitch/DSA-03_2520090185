let allItems = [];
let searchDebounce;

document.addEventListener("DOMContentLoaded", () => {
  loadItems();
  document.getElementById("searchInput").addEventListener("input", () => {
    clearTimeout(searchDebounce);
    searchDebounce = setTimeout(applyFiltersAndRender, 250);
  });
  document.getElementById("itemCategoryFilter").addEventListener("change", applyFiltersAndRender);
  document.getElementById("itemSortBy").addEventListener("change", applyFiltersAndRender);
});

async function loadItems() {
  const statusEl = document.getElementById("items-status");
  showLoading(statusEl, "Loading items...");
  try {
    allItems = await Api.getItems();
    statusEl.innerHTML = "";
    applyFiltersAndRender();
  } catch (err) {
    showError(statusEl, err);
  }
}

function applyFiltersAndRender() {
  const statusEl = document.getElementById("items-status");
  const cardsEl = document.getElementById("items-cards");
  const keyword = document.getElementById("searchInput").value.toLowerCase();
  const category = document.getElementById("itemCategoryFilter").value;
  const sortBy = document.getElementById("itemSortBy").value;

  let filtered = allItems.filter((item) => {
    const matchesKeyword = !keyword || item.itemName.toLowerCase().includes(keyword);
    const matchesCategory = !category || item.category === category;
    return matchesKeyword && matchesCategory;
  });

  filtered.sort((a, b) => (b[sortBy] || 0) - (a[sortBy] || 0));
  filtered = filtered.slice(0, 60); // keep the page snappy

  if (filtered.length === 0) {
    cardsEl.innerHTML = "";
    showEmpty(statusEl, "No items match your search.");
    return;
  }

  statusEl.innerHTML = "";
  cardsEl.innerHTML = filtered.map(renderItemCard).join("");
}

function renderItemCard(item) {
  return `
    <div class="card item-card">
      <h3>${item.itemName}</h3>
      <span class="badge">${item.category} · ${item.subcategory}</span>
      <p style="color:var(--text-muted); font-size:0.85rem;">${item.description}</p>
      <div class="score-row">
        <span>⭐ <b>${item.rating}</b></span>
        <span>💰 <b>₹${item.price}</b></span>
      </div>
      <div class="score-row">
        <span>Popularity: <b>${item.popularity}</b></span>
        <span>Quality: <b>${item.qualityScore}</b></span>
      </div>
    </div>
  `;
}

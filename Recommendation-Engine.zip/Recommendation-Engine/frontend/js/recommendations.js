let lastRecommendations = [];

document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("generateBtn").addEventListener("click", generateRecommendations);
  document.getElementById("resetBtn").addEventListener("click", resetControls);
  document.getElementById("categoryFilter").addEventListener("change", applyFiltersAndRender);
  document.getElementById("minRating").addEventListener("change", applyFiltersAndRender);
  document.getElementById("sortBy").addEventListener("change", applyFiltersAndRender);

  generateRecommendations();
});

function resetControls() {
  document.getElementById("userIdInput").value = 1;
  document.getElementById("categoryFilter").value = "";
  document.getElementById("minRating").value = "0";
  document.getElementById("limitInput").value = "10";
  document.getElementById("sortBy").value = "finalScore";
  generateRecommendations();
}

async function generateRecommendations() {
  const statusEl = document.getElementById("rec-status");
  const cardsEl = document.getElementById("rec-cards");
  const userId = document.getElementById("userIdInput").value;
  const limit = document.getElementById("limitInput").value;

  if (!userId || userId < 1) {
    showError(statusEl, new Error("Please enter a valid User ID."));
    cardsEl.innerHTML = "";
    return;
  }

  showLoading(statusEl, `Generating recommendations for user #${userId}...`);
  cardsEl.innerHTML = "";

  try {
    const data = await Api.getRecommendations(userId, limit);
    lastRecommendations = data.recommendations || [];
    statusEl.innerHTML = "";

    if (lastRecommendations.length === 0) {
      showEmpty(statusEl, data.message || "No recommendations found for this user.");
      return;
    }
    applyFiltersAndRender();
  } catch (err) {
    showError(statusEl, err);
  }
}

function applyFiltersAndRender() {
  const cardsEl = document.getElementById("rec-cards");
  const statusEl = document.getElementById("rec-status");
  const category = document.getElementById("categoryFilter").value;
  const minRating = parseFloat(document.getElementById("minRating").value);
  const sortBy = document.getElementById("sortBy").value;

  let filtered = [...lastRecommendations];

  if (category) filtered = filtered.filter((r) => r.category === category);
  if (minRating) filtered = filtered.filter((r) => (r.rating || 0) >= minRating);

  filtered.sort((a, b) => {
    if (sortBy === "rating") return (b.rating || 0) - (a.rating || 0);
    if (sortBy === "price") return (a.price || 0) - (b.price || 0);
    if (sortBy === "popularityScore") return (b.popularityScore || 0) - (a.popularityScore || 0);
    return (b.finalScore || 0) - (a.finalScore || 0);
  });

  if (filtered.length === 0) {
    cardsEl.innerHTML = "";
    showEmpty(statusEl, "No recommendations match the selected filters.");
    return;
  }

  statusEl.innerHTML = "";
  cardsEl.innerHTML = filtered.map(renderCard).join("");
}

function renderCard(rec) {
  const pct = (v) => Math.round((v || 0) * 100);
  return `
    <div class="card item-card">
      <div class="rank-badge">#${rec.rank}</div>
      <h3>${rec.itemName}</h3>
      <span class="badge">${rec.category}</span>
      <div class="score-row">
        <span>⭐ <b>${(rec.rating ?? "-").toFixed ? rec.rating.toFixed(1) : rec.rating}</b></span>
        <span>💰 <b>₹${rec.price}</b></span>
      </div>
      <div class="score-row"><span>Similarity: <b>${pct(rec.similarityScore)}%</b></span></div>
      <div class="progress-bar"><span style="width:${pct(rec.similarityScore)}%"></span></div>
      <div class="score-row"><span>Recommendation Score: <b>${pct(rec.finalScore)}%</b></span></div>
      <div class="progress-bar"><span style="width:${pct(rec.finalScore)}%"></span></div>
      <div class="score-row"><span>Popularity: <b>${pct(rec.popularityScore)}%</b></span></div>
    </div>
  `;
}

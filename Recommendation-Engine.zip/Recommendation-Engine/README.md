# Recommendation Engine

**Course:** Data Structures and Algorithms - 3 (25CS2103E)
**Academic Year:** 2026-2027 &nbsp;|&nbsp; **Team:** 37 &nbsp;|&nbsp; **Section:** 12
**Team Members:** Yaswanth H (2520090095), Venu Gopal (2520090185)
**Guide:** Chandusha Kanda &nbsp;|&nbsp; **University:** KL University, Hyderabad

---

## Abstract

The Recommendation Engine is a Java-based system that provides personalized
recommendations to users by analyzing their preferences, ratings, and
interactions with different items across ten categories (Electronics,
Books, Movies, Music, Sports, Fashion, Gaming, Food, Travel, Education).
The project demonstrates the practical application of core Data Structures
and Algorithms — `ArrayList`, `HashMap`, `HashSet`, and `PriorityQueue` —
combined with manually implemented Searching (Linear/Binary), Sorting
(Merge Sort), Similarity Calculation, and weighted Recommendation Ranking.

## Introduction

Recommendation systems are everywhere — e-commerce, streaming, social
media — and at their core they are a data structures and algorithms
problem: given a large catalog and a user's history, efficiently find and
rank the most relevant items. This project builds a complete, runnable
recommendation system end-to-end: dataset, database, Java backend
algorithm, REST API, and a web frontend.

## Problem Statement

Given a catalog of items, a set of users, their stated category
preferences, and their historical interactions, generate a ranked list of
the Top-N items each user is most likely to want — without recommending
anything they have already interacted with — using efficient data
structures rather than brute-force scanning and re-scanning.

## Objectives

- Demonstrate correct, efficient use of `ArrayList`, `HashMap`, `HashSet`,
  and `PriorityQueue` in a real application.
- Implement Linear Search, Binary Search, and Merge Sort manually.
- Design an understandable similarity + weighted scoring formula.
- Expose the algorithm through a clean REST API.
- Build a professional, responsive frontend to demonstrate the system live.

## Features

- 500 users, 500 items, 2,500+ interactions, 1,000+ preference records.
- Personalized Top-N recommendations per user, with cold-start fallback.
- Category / rating / price filtering and multi-criteria sorting.
- Live dashboard with Chart.js visualizations sourced from the backend.
- Full interaction history view per user.
- Clean error handling on both backend and frontend (no stack traces).

## Technology Stack

| Layer | Technology |
|---|---|
| Backend | Java 17, Spring Boot 3, Maven |
| Database | MySQL 8+ (Spring Data JPA / Hibernate) |
| Frontend | HTML5, CSS3, vanilla JavaScript, Chart.js |
| Dataset | CSV (users, items, interactions, preferences) |

## System Architecture

See [`docs/architecture.md`](docs/architecture.md) for the full diagram and
request-flow walkthrough. In short: **Frontend (fetch/JSON) → Spring Boot
REST API → Service layer → Algorithm layer (pure DSA) → JPA Repositories →
MySQL**.

## Data Structures

| Structure | Where it's used |
|---|---|
| `ArrayList<User/Item/Interaction/Recommendation>` | Holding all source data and results loaded from the database |
| `HashMap<Integer, User>` / `HashMap<Integer, Item>` | O(1) average user/item lookup by ID |
| `HashMap<String, Double>` | Best preference score per category |
| `HashSet<Integer>` | Already-interacted item IDs (prevents duplicate recommendations) |
| `HashSet<String>` | Unique categories, preferred-category membership checks |
| `PriorityQueue<Recommendation>` | Max-heap (via reversed `compareTo`) that always yields the highest-scoring candidate first |

## Algorithms

| Algorithm | File | Complexity |
|---|---|---|
| Linear Search | `algorithm/SearchAlgorithm.java` | O(n) |
| Binary Search | `algorithm/SearchAlgorithm.java` | O(log n), requires sorted input |
| Merge Sort | `algorithm/SortingAlgorithm.java` | O(n log n) |
| Similarity Calculation | `algorithm/SimilarityCalculator.java` | O(p), p = user's preference count |
| Full Recommendation Pipeline | `algorithm/RecommendationAlgorithm.java` | O(n·p + n log n) |

Full complexity breakdown: [`docs/dsa.md`](docs/dsa.md).

## Dataset

CSV files in `dataset/`:

- `users.csv` — 500 rows: `user_id, name, age, gender, location, preferred_category`
- `items.csv` — 500 rows: `item_id, item_name, category, subcategory, description, rating, price, popularity, quality_score`
- `interactions.csv` — 2,500 rows: `interaction_id, user_id, item_id, interaction_type, rating, timestamp`
- `preferences.csv` — 1,000+ rows: `user_id, category, preference_score`

All `user_id` and `item_id` values in `interactions.csv` and
`preferences.csv` are guaranteed to exist in `users.csv` / `items.csv`.

## Database Design

Five tables in MySQL: `users`, `items`, `interactions`, `preferences`,
`recommendations` — with primary keys, foreign keys (interactions/
preferences/recommendations reference users/items), a unique constraint on
`(user_id, category)` in `preferences`, and indexes on frequently filtered
columns (category, rating, user_id, item_id, interaction_type).

Full DDL, sample inserts, and useful SELECT/JOIN/aggregate queries:
[`database/recommendation_engine.sql`](database/recommendation_engine.sql).

## Recommendation Formula

```
finalScore =
      0.40 × preferenceScore
    + 0.30 × similarityScore
    + 0.15 × ratingScore
    + 0.10 × popularityScore
    + 0.05 × interactionScore
```

- **preferenceScore** — how strongly the user has rated this item's
  category in their `preferences` (0–1).
- **similarityScore** — `matchingPreferences / totalPreferences`, i.e. how
  much of the user's overall preference weight lines up with this item's
  category (plus a small subcategory-keyword bonus), normalized to 0–1.
- **ratingScore** — the item's average rating, normalized (`rating / 5`).
- **popularityScore** — the item's popularity relative to the
  most-popular item in the catalog.
- **interactionScore** — weighted signal from the user's past interaction
  types with that specific item (purchase > like > wishlist > rating >
  click > view), capped at 1.0.

All five components are normalized to `[0, 1]` before weighting, so
`finalScore` always falls in `[0, 1]`.

If a user has **no preferences and no interaction history** (cold start),
the algorithm falls back to the user's declared `preferred_category` plus
item popularity/rating only — see Part 4 of the spec, implemented in
`RecommendationAlgorithm.generateRecommendations()`.

## API Documentation

Base URL: `http://localhost:8080/api`

| Method | Endpoint | Description |
|---|---|---|
| GET | `/health` | Health check |
| GET | `/users` | List all users |
| GET | `/users/{id}` | Get a single user |
| GET | `/users/{id}/history` | Get a user's interaction history |
| GET | `/items` | List all items |
| GET | `/items/{id}` | Get a single item (binary search internally) |
| GET | `/items/search?keyword=` | Linear-search items by name keyword |
| GET | `/items/category/{category}` | Items filtered by category |
| GET | `/recommendations/{userId}?limit=10` | Top-N recommendations for a user |
| POST | `/interactions` | Record a new interaction |
| GET | `/statistics` | Aggregate stats for the dashboard |

Example response — `GET /api/recommendations/1?limit=1`:

```json
{
  "userId": 1,
  "count": 1,
  "recommendations": [
    {
      "rank": 1,
      "itemId": 105,
      "itemName": "Wireless Headphones",
      "category": "Electronics",
      "rating": 4.7,
      "price": 2999.0,
      "similarityScore": 0.92,
      "preferenceScore": 0.88,
      "ratingScore": 0.94,
      "popularityScore": 0.81,
      "interactionScore": 0.0,
      "finalScore": 0.9
    }
  ]
}
```

## Frontend

Six pages under `frontend/`: `index.html` (hero/landing),
`dashboard.html` (live stats + Chart.js), `recommendations.html`
(controls + ranked cards), `items.html` (browsable catalog),
`history.html` (interaction log table), `about.html` (project info + DSA
flow diagram for the viva). All styled with a single dark-blue
`css/style.css` theme and driven by `js/api.js` + one script per page.

## Backend

Spring Boot 3 / Java 17 application under `backend/`, structured into
`controller`, `service`, `algorithm`, `repository`, `model`, and `config`
packages (see [System Architecture](#system-architecture)).

---

## Installation (Windows 11 + VS Code)

### 1. Install prerequisites

1. **JDK 17** — download from [Adoptium Temurin 17](https://adoptium.net/) and install.
   Verify:
   ```
   java -version
   ```
2. **Maven** — download from [maven.apache.org](https://maven.apache.org/download.cgi),
   unzip, add its `bin` folder to your `PATH`. Verify:
   ```
   mvn -version
   ```
3. **MySQL 8+** — install [MySQL Community Server](https://dev.mysql.com/downloads/mysql/)
   (remember the root password you set during installation).
4. **VS Code** — install these extensions:
   - Extension Pack for Java (Microsoft)
   - Spring Boot Extension Pack (VMware)
   - Live Server (Ritwick Dey) — for serving the frontend

### 2. Set up the database

Open MySQL Workbench or the `mysql` command line:

```
mysql -u root -p
```

Then run the schema script:

```sql
SOURCE database/recommendation_engine.sql;
```

This creates the `recommendation_engine` database, all five tables, and
inserts a small sample dataset. To load the **full** CSV dataset
(500 users / 500 items / 2500+ interactions), enable local file loading
and uncomment the `LOAD DATA LOCAL INFILE` statements in the same file,
adjusting the file paths to your machine, e.g.:

```sql
SET GLOBAL local_infile = 1;
-- then run the LOAD DATA LOCAL INFILE statements from recommendation_engine.sql
```

### 3. Configure the backend

Open `backend/src/main/resources/application.properties` and replace:

```
spring.datasource.password=YOUR_MYSQL_PASSWORD
```

with your actual MySQL root password.

### 4. Run the backend

```
cd backend
mvn clean install
mvn spring-boot:run
```

The API starts on **http://localhost:8080**. Verify it's up:

```
curl http://localhost:8080/api/health
```

### 5. Run the frontend

In VS Code, right-click `frontend/index.html` → **"Open with Live Server"**
(default serves on `http://127.0.0.1:5500`, which is already allowed by
the backend's CORS configuration).

Alternatively, from a terminal:

```
cd frontend
npx serve -l 5500
```

### 6. Test it

Open `http://127.0.0.1:5500/index.html` in your browser, click
**"Get Recommendations"**, enter a User ID (e.g. `1`), and click
**Generate Recommendations**.

---

## Testing

See [`docs/testing.md`](docs/testing.md) for 10+ documented test cases
(input, expected output, actual output).

## Complexity Analysis

See [`docs/dsa.md`](docs/dsa.md) for the full Big-O breakdown of every
data structure and algorithm used.

## Advantages

- Clear separation between DSA logic and framework/web code — easy to
  explain and defend in a viva.
- O(1) average lookups via HashMap keep the pipeline fast even as the
  catalog grows.
- HashSet-based duplicate prevention is simple and provably correct.
- Cold-start handling means every user gets a reasonable recommendation,
  even with zero history.

## Limitations

- Similarity is category-based rather than deep content-based (no NLP/embeddings).
- No collaborative filtering across users (item-based/user-based CF is a natural extension).
- Recommendation results are computed on-demand rather than cached/pre-materialized.

## Future Scope

- Add collaborative filtering (user-user or item-item similarity).
- Cache/precompute recommendations in the `recommendations` table for faster reads.
- Add authentication and per-user login instead of manual User ID entry.
- Support pagination and infinite scroll on the Items page for larger catalogs.

## Conclusion

This project demonstrates that a recommendation engine — a system often
associated with complex machine learning — can be built with a clear,
explainable, and efficient DSA foundation: HashMaps for lookups, HashSets
for uniqueness, a PriorityQueue for ranking, and Merge Sort for a stable
final order, wrapped in a working full-stack application.

---

## Git Commands

```
git init
git add .
git commit -m "Initial commit - Recommendation Engine DSA-3 project"
git branch -M main
git remote add origin <your-repository-url>
git push -u origin main
```
